'use strict';

/**
 * @ngdoc function
 * @name angularMapMarkersApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the angularMapMarkersApp
 */
angular.module('angularMapMarkersApp')
  .controller('AboutCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
